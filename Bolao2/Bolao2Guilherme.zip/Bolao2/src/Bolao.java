public class Bolao {
    public static void main(String[] args) {

        System.out.println("*** JOGO DO BICHO 2.0 ***");

        Sistema sistema = new Sistema();

        sistema.mostrarMenu();

    }
}
